# $PAWS · Cat panics. Dog buys.

Site du memecoin $PAWS, tiré du meme chien vs chat : Panik le chat vend tout à la première bougie rouge, Bisky le chien la mange. Même graphique, deux réactions.
Tout tient dans `index.html`. Double-clique dessus pour l'ouvrir.

Rien sur ce site ne lit le prix ou la market cap.

## Contenu
- Hero en deux moitiés façon meme : "Cat when the chart goes red" / "Dog when the chart goes red"
- Les deux rivaux (fiches perso)
- **Pick a side** : Team Cat ou Team Dog. Ça change la couleur du site et ton camp dans le jeu, avec un bouton pour l'annoncer sur X. Le choix est sauvegardé dans le navigateur
- **Meme maker** : 4 modèles (Cat vs Dog, chat qui panique, chat smug, chien snack), texte du haut et du bas, bouton Random, téléchargement en PNG 1080×1080 avec le watermark $PAWS
- Mini-jeu **Paw Tug** : tir à la corde. Tape vite (bouton PULL, clic ou Espace) pour tirer le drapeau de ton côté. Chaque manche, l'adversaire tire plus fort. P pour pause, record sauvegardé
- Tokenomics, comment acheter, avertissement risques

## Le jour du lancement
Dans `index.html`, bloc `CONFIG` au début du dernier `<script>` :
- `contract` : colle l'adresse pump.fun (CA). Elle s'affiche partout et active les boutons pump.fun et DexScreener.
- `socials` : tes liens X et Telegram.

## Images
- `logo/paws-logo-1024.png` : l'image à mettre sur pump.fun et en photo de profil.
- `og-image.png` : l'aperçu quand le lien est partagé. Remplace `SITE_URL` dans `index.html` par l'adresse de ton site.
- `favicon.svg` : l'icône de l'onglet (déjà branchée).
